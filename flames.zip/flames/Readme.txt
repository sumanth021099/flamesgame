READ ME:
********

Usage
-----
1) Download and Unzip flames.zip to extract the files and folders.

2) This file contains index.html,flames.js,style.css and Readme.txt files and image folder.

Features
--------
a) Know what type of relationship with your life partner using this online love game.

b) This is fun, love and relationship game script.

c) Download javascript source code for free.

d) Fully responsible, easy to integrate.

e) Supports on all modern browsers.

Index.html
---------
1)This file contains the entire functionality of flames script.

flames.js
---------
2) Flames calculations are done in this js file.


Style.CSS:
----------
1) Style.css contains the 'CSS properties' of the script

2) CSS properties like 'Background, padding, margin, height, width, border' etc., can be modified according to your needs.

Note: Before replacing the stylesheet make sure that the classnames and id names are given properly, to avoid duplication.


How to embed the script in to your webpage?
-------------------------------------------
1) Run index.html in your browser. 

2) The script code is available inside the <body> of the index.html file. 

3) Image used in this flames game javascript can be changed according to your wish by giving correct image source in index.html.

4) In the <head> tag include 
		<link rel="stylesheet" type="text/css" href="style.css">
		<script type='text/javascript' src='flames.js'></script>
 
5) The function "calc()" in flames.js is used to find the relationship calculation.

6) The flames calculation statrs here by checking you and your partners name,
			   		 if(first[xx] == second[yy])
                                   	  {
                                            var a1 = first.substring(0,xx);
                                            var a2 = first.substring(xx+1,first.length);
                                            first = a1+a2;
                                            xx=-1;
                                            
                                            var b1 = second.substring(0,yy);
                                            var b2 = second.substring(yy+1,second.length);
                                            second = b1+b2;
                                            yy=-1;
                                             
                                            break;
                                    } 


Script provided by:
*******************

This software is developed and copyrighted by HIOX Softwares.
This is given under The GNU General Public License (GPL).
This version is flames 1.0

Downloads:
-----------
Please visit our site https://www.hscripts.com/scripts/JavaScript/flames.php and do the download

Releases:
----------
Release Date flames 1.0 : 16-04-2015.

On any suggestions mail to us at support@hscripts.com

Visit us at https://www.hscripts.com
Visit us at https://www.hioxindia.com
